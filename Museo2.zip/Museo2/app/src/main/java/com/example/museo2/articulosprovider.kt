package com.example.museo2

class articulosprovider {
    companion object{
        var articulosLista = listOf<articulos>(
            articulos(
                "noticia1",
                "https://www.fundacionaquae.org/wp-content/uploads/2020/06/superordenador.jpg",
                "https://www.technologyreview.es//s/14835/el-ultimo-desafio-de-la-ia-calcular-su-propia-huella-de-carbono"
            ),
            articulos(
                "noticia2",
                "https://img.blogs.es/intel/wp-content/uploads/2019/12/microcomputer-ibm-model-5140-1986-672541-medium-1080x675.jpg",
                "https://territoriointel.xataka.com/historia-ordenador-experiencia-nueve-profesionales-ambitos-muy-dispares/"
            ),
            articulos(
                "noticia3",
                "https://d2jhl5pzkfi24b.cloudfront.net/article_image/0001/04/3e27a83dfb644c9f0dfe01ea4221bcd6c1f3e4ac.jpeg",
                "https://www.technologyreview.es//s/14835/el-ultimo-desafio-de-la-ia-calcular-su-propia-huella-de-carbono"
            ),
            articulos(
                "noticia4",
                "https://www.fundacionaquae.org/wp-content/uploads/2020/06/superordenador.jpg",
                "https://www.technologyreview.es//s/14835/el-ultimo-desafio-de-la-ia-calcular-su-propia-huella-de-carbono"
            ),
            articulos(
                "noticia5",
                "https://i.blogs.es/3e7bdd/realidad-virtual/1366_2000.jpg",
                "https://www.technologyreview.es//s/14835/el-ultimo-desafio-de-la-ia-calcular-su-propia-huella-de-carbono"
            )
        )

    }
}