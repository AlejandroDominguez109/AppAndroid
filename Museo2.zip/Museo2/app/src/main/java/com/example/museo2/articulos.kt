package com.example.museo2

data class articulos (
    val titulo:String,
    val foto:String,
    val url:String)